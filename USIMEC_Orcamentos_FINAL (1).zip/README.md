
# USIMEC Orçamentos — versão final de desenvolvimento (v4)

Fluxo:
- Tela inicial com resumo
- Novo orçamento
- Seleção de cliente cadastrado
- Vários serviços/peças
- Cálculo automático
- Salvar no aparelho
- Histórico
- Detalhe do orçamento
- Status: PENDENTE / APROVADO / CANCELADO
- Duplicar orçamento com novo número
- Cancelar orçamento
- Gerar PDF
- Compartilhar PDF pelo Android/WhatsApp
- Cadastro de clientes
- Configuração dos dados da USIMEC
- Numeração automática

O PDF usa como referência visual o orçamento enviado pelo usuário.
A compilação do APK ainda depende de um ambiente Android/Gradle com SDK disponível.


package br.com.usimec.orcamentos

import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private val Blue = Color(0xFF0B4F8A)
private val BlueDark = Color(0xFF073A67)
private val Money = NumberFormat.getCurrencyInstance(Locale("pt","BR"))

data class Client(val id: Long, val name: String, val company: String, val doc: String, val phone: String, val address: String)
data class Item(var desc: String = "", var qty: Int = 1, var unit: Double = 0.0)
data class Quote(
    val number: Int,
    val clientId: Long,
    val clientName: String,
    val desc: String,
    val items: List<Item>,
    val deadline: String,
    var status: String = "PENDENTE",
    val created: String = SimpleDateFormat("dd/MM/yyyy", Locale("pt","BR")).format(Date())
)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("usimec_final", MODE_PRIVATE) }
    private val clients = mutableStateListOf<Client>()
    private val quotes = mutableStateListOf<Quote>()
    private var nextNumber by mutableIntStateOf(1)

    private var companyName by mutableStateOf("USIMEC USINAGEM E MANUTENÇÃO INDUSTRIAL LTDA")
    private var cnpj by mutableStateOf("67.757.780/0001-04")
    private var address by mutableStateOf("Rua Cuiabá, nº 26 – Terra dos Ipês I")
    private var city by mutableStateOf("Pindamonhangaba - SP • CEP 12443-510")
    private var whatsapp by mutableStateOf("(12) 97407-8979")
    private var email by mutableStateOf("usimecmanut@gmail.com")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue)) { App() }
        }
    }

    private fun load() {
        nextNumber = prefs.getInt("next", 1)
        companyName = prefs.getString("companyName", companyName) ?: companyName
        cnpj = prefs.getString("cnpj", cnpj) ?: cnpj
        address = prefs.getString("address", address) ?: address
        city = prefs.getString("city", city) ?: city
        whatsapp = prefs.getString("whatsapp", whatsapp) ?: whatsapp
        email = prefs.getString("email", email) ?: email

        val ca = JSONArray(prefs.getString("clients", "[]"))
        for (i in 0 until ca.length()) {
            val o = ca.getJSONObject(i)
            clients.add(Client(o.getLong("id"), o.getString("name"), o.getString("company"),
                o.getString("doc"), o.getString("phone"), o.getString("address")))
        }

        val qa = JSONArray(prefs.getString("quotes", "[]"))
        for (i in 0 until qa.length()) {
            val o = qa.getJSONObject(i)
            val ia = o.getJSONArray("items")
            val list = mutableListOf<Item>()
            for (j in 0 until ia.length()) {
                val x = ia.getJSONObject(j)
                list.add(Item(x.getString("desc"), x.getInt("qty"), x.getDouble("unit")))
            }
            quotes.add(Quote(o.getInt("number"), o.getLong("clientId"), o.getString("clientName"),
                o.getString("desc"), list, o.getString("deadline"), o.optString("status","PENDENTE"),
                o.optString("created","")))
        }
    }

    private fun save() {
        val ca = JSONArray()
        clients.forEach {
            ca.put(JSONObject().put("id", it.id).put("name", it.name).put("company", it.company)
                .put("doc", it.doc).put("phone", it.phone).put("address", it.address))
        }
        val qa = JSONArray()
        quotes.forEach { q ->
            val ia = JSONArray()
            q.items.forEach { ia.put(JSONObject().put("desc", it.desc).put("qty", it.qty).put("unit", it.unit)) }
            qa.put(JSONObject().put("number", q.number).put("clientId", q.clientId)
                .put("clientName", q.clientName).put("desc", q.desc).put("deadline", q.deadline)
                .put("status", q.status).put("created", q.created).put("items", ia))
        }
        prefs.edit()
            .putInt("next", nextNumber)
            .putString("companyName", companyName).putString("cnpj", cnpj)
            .putString("address", address).putString("city", city)
            .putString("whatsapp", whatsapp).putString("email", email)
            .putString("clients", ca.toString()).putString("quotes", qa.toString()).apply()
    }

    private fun total(q: Quote) = q.items.sumOf { it.qty * it.unit }

    private fun createPdf(q: Quote): File {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        fun text(s: String, x: Float, y: Float, size: Float, bold: Boolean = false, color: Int = Color.BLACK) {
            p.textSize = size
            p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.color = color
            c.drawText(s, x, y, p)
        }
        fun bar(y: Float) {
            p.color = android.graphics.Color.rgb(11, 79, 138)
            c.drawRect(18f, y, 577f, y + 18f, p)
        }

        val logo = BitmapFactory.decodeResource(resources, R.drawable.logo_usimec)
        c.drawBitmap(logo, null, RectF(18f, 12f, 155f, 78f), p)
        text(companyName, 166f, 27f, 10f, true)
        text("CNPJ: $cnpj", 166f, 42f, 8f)
        text(address, 166f, 54f, 8f)
        text(city, 166f, 66f, 8f)
        text("WhatsApp: $whatsapp", 166f, 78f, 8f)
        text("E-mail: $email", 350f, 78f, 8f)

        bar(90f)
        text("ORÇAMENTO", 20f, 115f, 16f, true)
        val year = Calendar.getInstance().get(Calendar.YEAR)
        text("Nº: %03d/%d".format(q.number, year), 455f, 108f, 9f, true)
        text("Emissão: ${q.created}", 455f, 120f, 8f)
        text("Validade: 15 dias", 455f, 132f, 8f)

        var y = 148f
        fun section(title: String) {
            bar(y); text(title, 24f, y + 13f, 9f, true, Color.WHITE); y += 18
        }

        section("DADOS DO CLIENTE")
        val client = clients.firstOrNull { it.id == q.clientId }
        text("Cliente:", 25f, y + 14f, 8f, true); text(q.clientName.ifBlank{"Não informado"}, 95f, y + 14f, 8f); y += 22
        text("Razão social:", 25f, y + 14f, 8f, true); text(client?.company?.ifBlank{"Não informado"} ?: "Não informado", 95f, y + 14f, 8f); y += 18
        text("CNPJ/CPF:", 25f, y + 14f, 8f, true); text(client?.doc?.ifBlank{"Não informado"} ?: "Não informado", 95f, y + 14f, 8f); y += 18
        text("Endereço:", 25f, y + 14f, 8f, true); text(client?.address?.ifBlank{"Não informado"} ?: "Não informado", 95f, y + 14f, 8f); y += 24

        section("OBJETO DO ORÇAMENTO")
        text(q.desc.ifBlank{"Fornecimento e execução de serviços de usinagem conforme itens e especificações abaixo."}, 25f, y + 14f, 8f)
        y += 28

        section("SERVIÇOS / PEÇAS")
        text("ITEM",23f,y+13f,7f,true); text("DESCRIÇÃO",59f,y+13f,7f,true)
        text("QTD.",335f,y+13f,7f,true); text("VALOR UNIT.",390f,y+13f,7f,true); text("VALOR TOTAL",490f,y+13f,7f,true)
        y += 20
        q.items.forEachIndexed { i, it ->
            text("%02d".format(i+1),23f,y+12f,8f)
            text(it.desc.take(34),59f,y+12f,8f)
            text(it.qty.toString(),335f,y+12f,8f)
            text(Money.format(it.unit),390f,y+12f,8f)
            text(Money.format(it.qty*it.unit),490f,y+12f,8f)
            p.style=Paint.Style.STROKE; p.color=Color.LTGRAY; c.drawRect(18f,y,577f,y+18f,p); p.style=Paint.Style.FILL
            y += 18
        }

        bar(y); text("VALOR TOTAL DO ORÇAMENTO",25f,y+15f,9f,true,Color.WHITE)
        text(Money.format(total(q)),485f,y+15f,9f,true,Color.WHITE); y += 35

        text("Validade da proposta",25f,y,8f,true); text("15 dias a partir da data de emissão",150f,y,8f); y += 15
        text("Prazo de entrega",25f,y,8f,true); text(q.deadline.ifBlank{"A combinar"},150f,y,8f); y += 15
        text("Condição de pagamento",25f,y,8f,true); text("Entrada de 50% após aprovação do orçamento e disponibilidade da peça",150f,y,8f); y += 15
        text("Nota Fiscal",25f,y,8f,true); text("Emissão conforme serviço faturado",150f,y,8f); y += 26
        text("• O preço não estará sujeito a aprovação fora do orçamento.",25f,y,7f); y += 11
        text("• Alterações de escopo, medidas, material ou condições inicialmente informadas poderão resultar em revisão de prazo e valor.",25f,y,7f)

        text("USIMEC – Responsável / Data",95f,775f,7f)
        text("APROVAÇÃO DO CLIENTE – Nome / Assinatura / Data",320f,775f,7f)
        bar(790f)
        text("USIMEC • USINAGEM • MANUTENÇÃO • SOLUÇÕES INDUSTRIAIS",150f,812f,8f,true,Color.rgb(11,79,138))

        doc.finishPage(page)
        val dir=File(cacheDir,"pdfs"); dir.mkdirs()
        val f=File(dir,"Orcamento_%03d_%d.pdf".format(q.number,year))
        doc.writeTo(f.outputStream()); doc.close()
        return f
    }

    private fun sharePdf(q: Quote, context: Context) {
        val f = createPdf(q)
        val uri = FileProvider.getUriForFile(context, "$packageName.fileprovider", f)
        context.startActivity(Intent(Intent.ACTION_SEND).apply {
            type="application/pdf"; putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Orçamento USIMEC Nº %03d/%d".format(q.number, Calendar.getInstance().get(Calendar.YEAR)))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }

    @Composable fun App() {
        var screen by remember { mutableStateOf("home") }
        var selectedQuote by remember { mutableStateOf<Quote?>(null) }

        when(screen) {
            "home" -> Home(
                onNew={screen="new"},
                onClients={screen="clients"},
                onSettings={screen="settings"},
                onQuote={q->{selectedQuote=q;screen="detail"}}
            )
            "new" -> NewQuote(onBack={screen="home"}) { q->
                quotes.add(0,q); nextNumber++; save(); screen="home"
            }
            "clients" -> Clients(onBack={screen="home"})
            "settings" -> Settings(onBack={screen="home"})
            "detail" -> selectedQuote?.let { Detail(it, onBack={screen="home"}) }
        }
    }

    @Composable fun Header(title:String, onBack:(()->Unit)?=null) {
        Surface(color=Blue) {
            Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                if(onBack!=null) {
                    TextButton(onClick=onBack) { Text("‹",color=Color.White,fontSize=30.sp) }
                }
                Text("USIMEC",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold)
                Spacer(Modifier.width(10.dp)); Text(title,color=Color.White)
            }
        }
    }

    @Composable fun Home(onNew:()->Unit,onClients:()->Unit,onSettings:()->Unit,onQuote:(Quote)->Unit) {
        val pending=quotes.count{it.status=="PENDENTE"}
        val approved=quotes.count{it.status=="APROVADO"}
        val totalValue=quotes.sumOf{total(it)}
        val context=LocalContext.current
        Scaffold(topBar={Header("Orçamentos")},
            floatingActionButton={FloatingActionButton(onClick=onNew,containerColor=Blue){Text("+",color=Color.White,fontSize=28.sp)}}) { pad->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item {
                    Text("USIMEC Orçamentos",fontSize=22.sp,fontWeight=FontWeight.Bold)
                    Text("Crie, acompanhe e envie seus orçamentos.",color=Color.Gray)
                }
                item {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        Button(Modifier.weight(1f),onClick=onNew,colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("NOVO\nORÇAMENTO")}
                        OutlinedButton(Modifier.weight(1f),onClick=onClients){Text("CLIENTES")}
                        OutlinedButton(Modifier.weight(1f),onClick=onSettings){Text("EMPRESA")}
                    }
                }
                item {
                    Card(colors=CardDefaults.cardColors(containerColor=Blue)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceEvenly) {
                            Stat("TOTAL",quotes.size.toString())
                            Stat("PENDENTES",pending.toString())
                            Stat("APROVADOS",approved.toString())
                            Stat("VALOR",Money.format(totalValue))
                        }
                    }
                }
                item{Text("ORÇAMENTOS RECENTES",fontSize=18.sp,fontWeight=FontWeight.Bold,color=Blue)}
                if(quotes.isEmpty()) item{Text("Nenhum orçamento criado ainda.",color=Color.Gray)}
                items(quotes.take(10)){q->
                    Card(onClick={onQuote(q)}) {
                        Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Nº %03d/%d".format(q.number,Calendar.getInstance().get(Calendar.YEAR)),fontWeight=FontWeight.Bold,color=Blue)
                                Text(q.clientName.ifBlank{"Cliente não informado"})
                                Text(Money.format(total(q)),fontWeight=FontWeight.Bold)
                            }
                            StatusChip(q.status)
                        }
                    }
                }
            }
        }
    }

    @Composable fun Stat(label:String,value:String) {
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Text(value,color=Color.White,fontWeight=FontWeight.Bold,fontSize=16.sp)
            Text(label,color=Color.White,fontSize=10.sp)
        }
    }

    @Composable fun StatusChip(status:String) {
        val c=when(status){"APROVADO"->Color(0xFF2E7D32);"CANCELADO"->Color(0xFFC62828);else->Color(0xFFE68A00)}
        Surface(color=c.copy(alpha=.12f),shape=MaterialTheme.shapes.small){Text(status,color=c,fontWeight=FontWeight.Bold,fontSize=11.sp,modifier=Modifier.padding(horizontal=8.dp,vertical=5.dp))}
    }

    @Composable fun Detail(q:Quote,onBack:()->Unit) {
        val context=LocalContext.current
        Column(Modifier.fillMaxSize()) {
            Header("Orçamento Nº %03d".format(q.number),onBack)
            LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item{Text(q.clientName,fontSize=22.sp,fontWeight=FontWeight.Bold)}
                item{Text(q.desc,color=Color.Gray)}
                item{Text("Status",fontWeight=FontWeight.Bold);StatusChip(q.status)}
                item{Text("Itens",fontWeight=FontWeight.Bold,fontSize=18.sp)}
                items(q.items){it->Card{Row(Modifier.fillMaxWidth().padding(12.dp)){Text("${it.qty}x ${it.desc}",Modifier.weight(1f));Text(Money.format(it.qty*it.unit),fontWeight=FontWeight.Bold)}}}
                item{Text("TOTAL: "+Money.format(total(q)),fontSize=22.sp,fontWeight=FontWeight.Bold,color=Blue)}
                item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Button(Modifier.weight(1f),onClick={sharePdf(q,context)},colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("PDF / WhatsApp")}
                    OutlinedButton(Modifier.weight(1f),onClick={
                        val idx=quotes.indexOfFirst{it.number==q.number}
                        if(idx>=0){quotes[idx].status=if(q.status=="APROVADO")"PENDENTE" else "APROVADO";save()}
                        onBack()
                    }){Text(if(q.status=="APROVADO")"Voltar p/ pendente" else "Marcar aprovado")}
                }}
                item{OutlinedButton(Modifier.fillMaxWidth(),onClick={
                    val idx=quotes.indexOfFirst{it.number==q.number}
                    if(idx>=0){quotes[idx].status="CANCELADO";save()}
                    onBack()
                }){Text("Cancelar orçamento")}}
                item{Text("Duplicar orçamento",fontWeight=FontWeight.Bold);Button(onClick={
                    val copy=q.copy(number=nextNumber,status="PENDENTE",created=SimpleDateFormat("dd/MM/yyyy",Locale("pt","BR")).format(Date()))
                    quotes.add(0,copy);nextNumber++;save();onBack()
                },colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("Duplicar e criar novo número")}}
            }
        }
    }

    @Composable fun Clients(onBack:()->Unit) {
        var name by remember{mutableStateOf("")};var company by remember{mutableStateOf("")}
        var doc by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};var addr by remember{mutableStateOf("")}
        Column(Modifier.fillMaxSize()){Header("Clientes",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            item{OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("Nome")})}
            item{OutlinedTextField(company,{company=it},Modifier.fillMaxWidth(),label={Text("Razão social / Empresa")})}
            item{OutlinedTextField(doc,{doc=it},Modifier.fillMaxWidth(),label={Text("CPF / CNPJ")})}
            item{OutlinedTextField(phone,{phone=it},Modifier.fillMaxWidth(),label={Text("Telefone / WhatsApp")})}
            item{OutlinedTextField(addr,{addr=it},Modifier.fillMaxWidth(),label={Text("Endereço")})}
            item{Button(Modifier.fillMaxWidth(),onClick={
                if(name.isNotBlank()){clients.add(Client(System.currentTimeMillis(),name,company,doc,phone,addr));save();name="";company="";doc="";phone="";addr=""}
            },colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("Salvar cliente")}}
            item{Text("Clientes cadastrados",fontSize=18.sp,fontWeight=FontWeight.Bold)}
            items(clients){c->Card{Column(Modifier.padding(12.dp)){Text(c.name,fontWeight=FontWeight.Bold);if(c.company.isNotBlank())Text(c.company);if(c.phone.isNotBlank())Text(c.phone,color=Color.Gray)}}}
        }}
    }

    @Composable fun Settings(onBack:()->Unit) {
        var n by remember{mutableStateOf(companyName)};var c by remember{mutableStateOf(cnpj)}
        var a by remember{mutableStateOf(address)};var ci by remember{mutableStateOf(city)}
        var w by remember{mutableStateOf(whatsapp)};var e by remember{mutableStateOf(email)}
        Column(Modifier.fillMaxSize()){Header("Dados da empresa",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            item{OutlinedTextField(n,{n=it},Modifier.fillMaxWidth(),label={Text("Nome da empresa")})}
            item{OutlinedTextField(c,{c=it},Modifier.fillMaxWidth(),label={Text("CNPJ")})}
            item{OutlinedTextField(a,{a=it},Modifier.fillMaxWidth(),label={Text("Endereço")})}
            item{OutlinedTextField(ci,{ci=it},Modifier.fillMaxWidth(),label={Text("Cidade / CEP")})}
            item{OutlinedTextField(w,{w=it},Modifier.fillMaxWidth(),label={Text("WhatsApp")})}
            item{OutlinedTextField(e,{e=it},Modifier.fillMaxWidth(),label={Text("E-mail")})}
            item{Button(Modifier.fillMaxWidth(),onClick={companyName=n;cnpj=c;address=a;city=ci;whatsapp=w;email=e;save();Toast.makeText(this@MainActivity,"Dados salvos",Toast.LENGTH_SHORT).show()},colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("Salvar dados")}}
        }}
    }

    @Composable fun NewQuote(onBack:()->Unit,saveQuote:(Quote)->Unit) {
        var clientId by remember{mutableLongStateOf(0L)}
        var clientName by remember{mutableStateOf("")}
        var desc by remember{mutableStateOf("")};var deadline by remember{mutableStateOf("")}
        val items=remember{mutableStateListOf(Item())}
        Column(Modifier.fillMaxSize()){Header("Novo orçamento Nº %03d".format(nextNumber),onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            item{Text("Cliente",fontWeight=FontWeight.Bold)}
            item{
                if(clients.isEmpty()) {
                    OutlinedTextField(clientName,{clientName=it},Modifier.fillMaxWidth(),label={Text("Cliente / Empresa")})
                } else {
                    Column {
                        clients.forEach { c->
                            FilterChip(
                                selected=clientId==c.id,
                                onClick={clientId=c.id;clientName=c.name},
                                label={Text(if(c.company.isBlank())c.name else "${c.name} • ${c.company}")},
                                modifier=Modifier.padding(end=6.dp,bottom=5.dp)
                            )
                        }
                    }
                }
            }
            item{OutlinedTextField(desc,{desc=it},Modifier.fillMaxWidth(),label={Text("Objeto do orçamento")},minLines=2)}
            item{Text("Serviços / Peças",fontWeight=FontWeight.Bold,fontSize=18.sp)}
            items(items){it->Card{Column(Modifier.padding(12.dp)){
                OutlinedTextField(it.desc,{it.desc=it},Modifier.fillMaxWidth(),label={Text("Descrição")})
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedTextField(it.qty.toString(),{it.qty=it.toIntOrNull()?.coerceAtLeast(1)?:1},Modifier.weight(1f),label={Text("Qtd.")})
                    OutlinedTextField(it.unit.toString(),{it.unit=it.replace(',','.').toDoubleOrNull()?:0.0},Modifier.weight(2f),label={Text("Valor unit. (R$)")})
                }
                if(items.size>1)TextButton(onClick={items.remove(it)}){Text("Remover")}
            }}}
            item{TextButton(onClick={items.add(Item())}){Text("+ Adicionar item")}}
            item{OutlinedTextField(deadline,{deadline=it},Modifier.fillMaxWidth(),label={Text("Prazo de entrega")})}
            item{Text("TOTAL: "+Money.format(items.sumOf{it.qty*it.unit}),fontSize=21.sp,fontWeight=FontWeight.Bold,color=Blue)}
            item{Button(Modifier.fillMaxWidth(),onClick={
                if(clientName.isBlank()){Toast.makeText(this@MainActivity,"Informe o cliente",Toast.LENGTH_SHORT).show()}
                else saveQuote(Quote(nextNumber,clientId,clientName,desc,items.toList(),deadline))
            },colors=ButtonDefaults.buttonColors(containerColor=Blue)){Text("SALVAR ORÇAMENTO")}}
        }}
    }
}


# USIMEC Orçamentos — pacote final

O aplicativo está estruturado como projeto Android nativo.

## Caminho mais simples (sem instalar Android Studio)

1. Crie um repositório no GitHub.
2. Envie todo o conteúdo deste ZIP para o repositório.
3. Abra a aba **Actions**.
4. Execute **Build USIMEC APK**.
5. Quando terminar, abra a execução concluída.
6. Em **Artifacts**, baixe **USIMEC-Orcamentos-APK**.
7. Extraia o ZIP e instale `app-debug.apk` no Android.

A automação usa Java 17, Gradle 8.7 e Android SDK 35.

## Caminho pelo Windows

Se o computador já tiver Gradle + Android SDK configurados, execute:

`gerar_apk.bat`

O APK será gerado em:

`app/build/outputs/apk/debug/app-debug.apk`

## O que já está no aplicativo

- Tela inicial USIMEC
- Novo orçamento
- Cadastro de clientes
- Seleção de cliente
- Vários serviços/peças
- Quantidade, valor unitário e total
- Numeração automática
- Histórico local
- Status pendente/aprovado/cancelado
- Duplicar orçamento
- Cancelar orçamento
- Configurações dos dados da USIMEC
- Geração de PDF
- Compartilhamento do PDF pelo Android/WhatsApp
- Logo e identidade visual baseados no orçamento de referência

## Observação

O APK final precisa ser compilado em um ambiente Android/Gradle. Este pacote inclui a automação de build para fazer isso no GitHub Actions, sem precisar configurar o Android Studio.

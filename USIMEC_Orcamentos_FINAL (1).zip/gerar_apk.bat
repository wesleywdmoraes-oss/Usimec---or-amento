@echo off
title USIMEC - Gerar APK
echo ==========================================
echo      USIMEC ORCAMENTOS - GERAR APK
echo ==========================================
echo.
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle nao foi encontrado neste computador.
  echo Use o arquivo .github/workflows/build-apk.yml pelo GitHub,
  echo ou instale o Android Studio/Gradle.
  pause
  exit /b 1
)
gradle --no-daemon assembleDebug
if errorlevel 1 (
  echo.
  echo A compilacao falhou. Veja a mensagem acima.
  pause
  exit /b 1
)
echo.
echo APK criado em:
echo app\build\outputs\apk\debug\app-debug.apk
pause
